package TraingAqua;

public class Employee1 {
    private String name;
    private int Empno;
    
    public String getName() 
    {
        return name;
     }     
    public int getEmpno() 
    {
    return Empno;
    }
    public void setName(String newName) 
      {
      name = newName;
      }
     public void setEmpno(int Rollno)
      {
          Empno = Rollno;
      }
}

/* output:

Constructor Method
EmpName:Mani
Rollno:2959
*/